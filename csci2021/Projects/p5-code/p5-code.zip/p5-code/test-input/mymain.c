#include <stdio.h>
int main(int argc, char *argv[]){
  printf("hello world\n");
  return 0;
}

int say_hello(){
  printf("hello world\n");
  return 7;
}

int return_seven(){
  return 7;
}
