var searchData=
[
  ['beelinestrategy_4',['BeelineStrategy',['../classBeelineStrategy.html',1,'BeelineStrategy'],['../classBeelineStrategy.html#a5672d5a2f179ccde216e46ca1ee2281d',1,'BeelineStrategy::BeelineStrategy()']]]
];
