var searchData=
[
  ['helicopter_130',['Helicopter',['../classHelicopter.html#a729e9ff6a148d20c9112818f950a177a',1,'Helicopter::Helicopter(JsonObject &amp;obj)'],['../classHelicopter.html#ac5367f0bff526ed489110d45792d9b55',1,'Helicopter::Helicopter(const Helicopter &amp;helicopter)=delete']]],
  ['human_131',['Human',['../classHuman.html#acc063ebc1748add91092a9fd3302f03e',1,'Human::Human(JsonObject &amp;obj)'],['../classHuman.html#ad1243f1e38f527c3c0bdf3d83299e266',1,'Human::Human(const Human &amp;human)=delete']]]
];
