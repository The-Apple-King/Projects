#ifndef SIMULATION_DATA_COLLECTOR_H
#define SIMULATION_DATA_COLLECTOR_H

#include <vector>
#include <string>
#include "Data.h"

class SimulationDataCollector {
public:
    static SimulationDataCollector* getInstance();

    void collectData(Data* data);

    void outputDataToCSV(std::string fileName);

private:
    static SimulationDataCollector* Instance() { static SimulationDataCollector s; return &s; }
    SimulationDataCollector(); // Private constructor to prevent direct instantiation
    SimulationDataCollector(SimulationDataCollector const&) = delete; // Delete copy constructor
    void operator=(SimulationDataCollector const&) = delete; // Delete assignment operator

    std::vector<Data*> collectedData;
protected:
    static SimulationDataCollector* singleton_;
};


#endif /* SIMULATION_DATA_COLLECTOR_H */
