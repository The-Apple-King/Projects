#include "SimulationDataCollector.h"
#include "Data.h"
#include <fstream>

SimulationDataCollector* SimulationDataCollector::singleton_ = 0;

SimulationDataCollector::SimulationDataCollector(){
    collectedData = std::vector<Data *>();
}



SimulationDataCollector *SimulationDataCollector::getInstance()
{
    /**
     * This is a safer way to create an instance. instance = new Singleton is
     * dangeruous in case two instance threads wants to access at the same time
     */
    if(singleton_== nullptr){
        singleton_ = new SimulationDataCollector();
    }
    return singleton_;
}

void SimulationDataCollector::collectData(Data* trip) {
    // Add data to the internal data vector
    collectedData.push_back(trip);
}

void SimulationDataCollector::outputDataToCSV(std::string filename) {
    // Open the file for writing
    std::ofstream outputFile(filename);

    // Write the header row
    outputFile << "Simulation ID,Simulation Value\n";

    // Write the data rows
    if(!collectedData.empty()){
        for (int i = 0; i < collectedData.size()-1; i ++) {
            outputFile << collectedData[i]->toString();
        }
    }

    // Close the file
    outputFile.close();
}

