# CSCI4211_rdt_java

How to run:
1. install Java JDK (I used openjdk version "1.8.0_242")
2. go to the src folder
3. run `javac simulator.java`
4. run `java simulator`

Updates:
1. add constructors for acknowledgement packets in packet.java: `public packet(int acknum)`.
