public class msg {
    char[] data;
    public msg(char a){
        data= new char [20];
        for (int i=0;i<20;i++){
            data[i]=a;
        }
    }
}
