# CSCI4211_rdt_python

How to run:
1. install Python 3
2. go to the root folder
3. run `python3 main.py`
