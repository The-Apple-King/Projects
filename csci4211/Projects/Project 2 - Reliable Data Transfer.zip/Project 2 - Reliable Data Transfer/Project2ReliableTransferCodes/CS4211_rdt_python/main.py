

from pj2 import sim

sim.run()








