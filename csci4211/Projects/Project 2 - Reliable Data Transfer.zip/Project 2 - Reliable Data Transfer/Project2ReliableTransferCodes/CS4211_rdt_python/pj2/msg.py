class msg:
    def __init__(self,i):
        temp=str(i)
        self.data=""
        for i in range(20):
            self.data=self.data+temp